const home = () => {
  return (
    <div>
      <div>Home Page</div>
    </div>
  );
};

export default home;
