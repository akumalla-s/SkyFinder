import { useState } from "react";

function Register() {
  const [id, setId] = useState("");
  const [firstname, setFname] = useState("");

  async function handleSubmit(event) {}

  return (
    <div className="register">
      <form className="register-form" onSubmit={handleSubmit}>
        <br></br>
        <h1>Register</h1>
        <p>Fill in the Information Below</p>
        <input
          type="text"
          name="id"
          placeholder="id"
          onChange={(event) => {
            setId(event.target.value);
          }}
        />
        <input
          type="text"
          name="firstname"
          placeholder="Firstname"
          onChange={(event) => {
            setFname(event.target.value);
          }}
        />
        <br />
        ID: {id}
        First Name:
        {firstname}
        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default Register;
