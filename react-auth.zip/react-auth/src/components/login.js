import { useState } from "react";
import { useNavigate } from "react-router-dom";
import AuthService from "../services/authService";

const Login = () => {
  let navigate = useNavigate();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  async function handleSubmit(e) {
    e.preventDefault();
    AuthService.login(username, password).then((data) => {
      console.log(data);
      if (data.status) {
        if (data.status === "success") {
          navigate("/profile");
          window.location.reload();
        } else {
          setErrorMsg(data.error);
        }
      } else {
        setErrorMsg("Service is not available");
      }
    });
  }

  return (
    <div className="login">
      <form className="login-form" onSubmit={handleSubmit}>
        <br></br>
        <h1>Login</h1>
        <br />
        <div className="alert alert-danger" role="alert">
          {errorMsg}
        </div>
        <input
          type="text"
          name="username"
          placeholder="username"
          onChange={(event) => {
            setUsername(event.target.value);
          }}
        />
        <br />

        <input
          type="text"
          name="password"
          placeholder="password"
          onChange={(event) => {
            setPassword(event.target.value);
          }}
        />
        <br />
        <button type="submit">Login</button>
      </form>
    </div>
  );
};

export default Login;
