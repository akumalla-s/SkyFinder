import React from "react";
import HelperService from "../services/helperService";

const Profile = () => {
  const userData = HelperService.getCurrentUserData();
  console.log(userData);
  return (
    <div>
      <div>Welcome {userData.userName}</div>
    </div>
  );
};

export default Profile;
