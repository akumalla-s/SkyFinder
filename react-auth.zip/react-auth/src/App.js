import React, { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";

import "./App.css";

import HelperService from "./services/helperService";

import PageHeader from "./layouts/pageHeader";

import Home from "./components/home";
import Register from "./components/register";
import Login from "./components/login";
import Profile from "./components/profile";

function App() {
  const [currentUser, setCurrentUser] = useState(undefined);
  const [role, setRole] = useState("NONE");

  useEffect(() => {
    console.log("[]");
    const user = HelperService.getCurrentUserData();
    if (user) {
      console.log(user);
      console.log(user.role);
      setCurrentUser(user);
      if (user.role === "USER") {
        setRole("USER");
      } else if (user.role === "ADMIN") {
        setRole("ADMIN");
      } else {
        setRole("NONE");
      }
    } else {
      // User is not Set
      setRole("NONE");
    }
  }, []); //Called

  const logout = () => {
    //AuthService.logout();
  };

  return (
    <div className="App">
      <header>
        <Router>
          <nav>
            <NavLink activeclassname="active" to="/">
              Home
            </NavLink>
            |
            <NavLink activeclassname="active" to="/register">
              Register
            </NavLink>
            |
            {currentUser ? (
              <NavLink activeclassname="active" to="/Login">
                Logout
              </NavLink>
            ) : (
              <NavLink activeclassname="active" to="/Login">
                Login
              </NavLink>
            )}
          </nav>
          <br />
          <br />
          Role: {role} |
          {role === "USER" && (
            <NavLink activeclassname="active" to="/Login">
              View User
            </NavLink>
          )}
          <br />
          <Routes>
            <Route exact path="/" element={<Home />} />
            <Route exact path="/register" element={<Register />} />
            <Route exact path="/login" element={<Login />} />
            <Route exact path="/profile" element={<Profile />} />

            <Route path="*" element={<Home />} />
          </Routes>
        </Router>
      </header>
    </div>
  );
}

export default App;
