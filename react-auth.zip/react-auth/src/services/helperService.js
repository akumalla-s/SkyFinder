const makeAPICall = async (url, method, headers, body) => {
  headers.append("Content-Type", "application/json");

  var requestOptions = {
    method: method,
    headers: headers,
  };

  if (method === "POST") {
    requestOptions[body] = body;
  }

  let data = await fetch(url, requestOptions)
    .then((response) => response.text)
    .then((result) => {
      return result;
    })
    .catch((error) => {
      return error;
    });

  return data;
};

const getCurrentUserData = () => {
  return JSON.parse(localStorage.getItem("userData"));
};

const HelperService = {
  makeAPICall,
  getCurrentUserData,
};

export default HelperService;
