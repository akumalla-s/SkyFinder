import AuthHeader from "./authHeader";
import HelperService from "./helperService";

const API_USER_URL = "http://localhost:8182/company1/user";

const getAllUsers = () => {
  let data = HelperService.makeAPICall(
    API_USER_URL + "/USER",
    "GET",
    AuthHeader.authHeader(),
    null
  );
  console.log(data);
  return data;
};

const UserService = {
  getAllUsers,
};

export default UserService;
