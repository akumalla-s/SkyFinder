const API_AUTH_URL = "http://localhost:8182/company1/auth";

const login = async (username, password) => {
  var myHeaders = new Headers();
  myHeaders.append("Content-Type", "application/json");

  var raw = JSON.stringify({
    username: username,
    password: password,
  });

  var requestOptions = {
    method: "POST",
    headers: myHeaders,
    body: raw,
  };

  const fetchAuthAPIResp = await fetch(API_AUTH_URL, requestOptions);
  const authAPIData = await fetchAuthAPIResp.json();

  var userData = {
    status: "success",
    userName: username,
    role: "USER",
    token: authAPIData["token"],
  };

  localStorage.setItem("userData", JSON.stringify(userData));
  console.log(userData);

  return userData;
};

const logout = () => {
  localStorage.removeItem("userData");
};

const AuthService = {
  login,
  logout,
};

export default AuthService;
