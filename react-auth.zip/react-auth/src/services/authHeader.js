const authHeader = () => {
  const userData = JSON.parse(localStorage.getItem("userData"));

  if (userData && userData.token) {
    return { Authorization: "Bearer " + userData.token };
  } else {
    return {};
  }
};

export default { authHeader };
