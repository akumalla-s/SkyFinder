import React from "react";
import { NavLink } from "react-router-dom";

function PageHeader() {
  return (
    <nav>
      <NavLink activeclassname="active" to="/">
        Home
      </NavLink>
      |
      <NavLink activeclassname="active" to="/register">
        Register
      </NavLink>
      |
      <NavLink activeclassname="active" to="/Login">
        Login
      </NavLink>
    </nav>
  );
}

export default PageHeader;
