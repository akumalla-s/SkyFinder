package neu.edu.skyfinder;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SkyFinderApplication {

	public static void main(String[] args) {
		SpringApplication.run(SkyFinderApplication.class, args);
	}

}
